// Import Mongoose
const mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect('mongodb://localhost/teamwork_timesheet', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define a schema for the Timesheet model
const timesheetSchema = new mongoose.Schema({
  projectId: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  hoursWorked: { type: Number, required: true },
});

// Create a Mongoose model based on the schema
const Timesheet = mongoose.model('Timesheet', timesheetSchema);

// Handle adding a new timesheet for the specified project
app.post('/api/projects/:projectId/timesheets', (req, res) => {
  const { projectId } = req.params;
  const { startDate, endDate, hoursWorked } = req.body;

  // Validate inputs
  // ...

  // Create a new timesheet instance
  const timesheet = new Timesheet({
    projectId,
    startDate,
    endDate,
    hoursWorked,
  });

  // Save the timesheet to the database
  timesheet.save()
    .then(() => {
      res.status(201).json(timesheet);
    })
    .catch((error) => {
      res.status(500).json({ error: 'Failed to save timesheet' });
    });
});
