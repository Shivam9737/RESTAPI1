// Import testing dependencies
const chai = require('chai');
const chaiHttp = require('chai-http');
const expect = chai.expect;

// Configure Chai
chai.use(chaiHttp);

// Write unit tests
describe('Timesheet API', () => {
  it('should add a new timesheet for a project', (done) => {
    const timesheetData = {
      startDate: '2023-06-01',
      endDate: '2023-06-07',
      hoursWorked: 40,
    };

    chai.request(app)
      .post('/api/projects/project123/timesheets')
      .send(timesheetData)
      .end((error, res) => {
        expect(res).to.have.status(201);
        expect(res.body).to.have.property('_id');
        expect(res.body.startDate).to.equal(timesheetData.startDate);
        // Add more assertions as needed

        done();
      });
  });
});
